<?php

	$setting=unserialize(@file_get_contents(DATA_DIR.'/setting/overnotes.dat'));
	ini_set('mbstring.http_input', 'pass');
	parse_str($_SERVER['QUERY_STRING'],$_GET);
	$keyword=isset($_GET['k'])?trim($_GET['k']):'';
	$category=isset($_GET['c'])?trim($_GET['c']):'';
	$page=isset($_GET['p'])?trim($_GET['p']):'';
	$base_title = !empty($setting['title'])? $setting['title'] : 'OverNotes';

?><!Doctype html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="format-detection" content="telephone=no">
<title></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="Content-Style-Type" content="text/css" />
<meta http-equiv="Content-Script-Type" content="text/javascript" />
<link  href="../css/styles.css" rel="stylesheet" type="text/css" />
<link  href="../css/style_sp.css" rel="stylesheet" type="text/css" />
<link  href="../css/responsive.css" rel="stylesheet" type="text/css" />
<link  href="../css/under.css" rel="stylesheet" type="text/css" />
<link  href="../css/under_responsive.css" rel="stylesheet" type="text/css" />
<script src="../js/jquery.js" type="text/javascript"></script>
<script src="../js/jquery.scroll.js" type="text/javascript"></script>
<script src="../js/rollover.min.js" type="text/javascript"></script>
<script src="../js/common.js" type="text/javascript"></script>
<script src="../js/jquery.fontResizer.js" type="text/javascript"></script>
<script src="../js/jquery.cookie.js" type="text/javascript"></script>

<!-- Google Analytics start -->
<!-- Google Analytics end -->
</head>

<body id="" class="under">
<div id="wrapper">
  <div id="header" class="clearfix">
    <h1 id="top"></h1>
  </div>
  
  <!-- main start -->
  <div id="main" class="clearfix">
    <div id="top_info" class="clearfix">
      <div class="inner clearfix">
        <h2>インプラント(h2)</h2>
      </div>
    </div>
    <div id="topic_path" class="clearfix">
      <div class="inner clearfix">
        <ul>
          <li><a href="">ホーム</a>&nbsp;&gt;&nbsp;</li>
          <li>下層ページ</li>
        </ul>
      </div>
    </div>
    <!-- content start -->
    <div class="inner clearfix">
    <div id="content" class="clearfix"> 
       <h3>安全・確実なインプラント治療（ｈ3）</h3>
        <h4>安全・確実なインプラント治療（ｈ4）</h4>
        <h5>当院院長は日本口腔インプラント学会専門医です（ｈ5）</h5>
        <h6>h6が入ります。</h6>
        <div class="section clearfix">
          <p>ダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミー</p>
          <p>ダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミーダミー</p>
          <table>
            <tr>
              <th>ダミーダミーダミーダ</th>
              <td>ダミーダミーダミーダ</td>
              <td>ダミーダミーダミーダ</td>
            </tr>
            <tr>
              <th class="bg_th01">ダミーダミーダミーダ</th>
              <td>ダミーダミーダミーダ</td>
              <td>ダミーダミーダミーダ</td>
            </tr>
            <tr>
              <th>ダミーダミーダミーダ</th>
              <td>ダミーダミーダミーダ</td>
              <td>ダミーダミーダミーダ</td>
            </tr>
          </table>
          <div class="frame01 clearfix">
            <ul class="list01">
              <li>天然歯のような咬み心地を得られる</li>
              <li>見ためがとても自然</li>
              <li>耐久性が高い</li>
              <li>まわりの歯を削るなど、負担をかけない</li>
            </ul>
          </div>
        </div>
        <!-- 1 -->
        
        <div class="gMap gMapZoom15 gMapDisableScrollwheel gMapNavigationSmall gMapMinifyInfoWindow" style="width: 480px; height: 360px;">
          <div class="gMapCenter">
            <p class="gMapLatLng">35.6150015,139.67307979999998</p>
          </div>
          <div class="gMapMarker">
            <div class="gMapInfoWindow"><span style="font-weight: bold">バルーン</span> </div>
            <p class="gMapLatLng">35.6150015,139.67307979999998</p>
          </div>
        </div>
        
        <!-- //1 --> 
        <!-- 2 -->
        <div class="gMap gMapZoom15 gMapDisableScrollwheel gMapNavigationSmall" style="width: 480px; height: 360px;">
          <div class="gMapCenter">
            <p class="gMapLatLng">35.6150015,139.67307979999998</p>
          </div>
          <div class="gMapMarker">
            <div class="gMapInfoWindow"><span style="font-weight: bold">バルーン</span> </div>
            <p class="gMapLatLng">35.6150015,139.67307979999998</p>
          </div>
        </div>
        
        <!-- //2 --> 
      </div>
      <div id="navi">
      	
      </div>
    </div>
    <!-- content end --> 
    
  </div>
  <!-- main end -->
  
  <div id="footer">
    <address>
    Copyright &copy; All Rights Reserved.
    </address>
  </div>
</div>
<script type="text/javascript" src="../js/gmaps.js"></script> 
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=ここにAPIキー&callback=gmaps.renderAll"></script>
</body>
</html>