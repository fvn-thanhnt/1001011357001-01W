<?php

	$setting=unserialize(@file_get_contents(DATA_DIR.'/setting/overnotes.dat'));
	ini_set('mbstring.http_input', 'pass');
	parse_str($_SERVER['QUERY_STRING'],$_GET);
	$keyword=isset($_GET['k'])?trim($_GET['k']):'';
	$category=isset($_GET['c'])?trim($_GET['c']):'';
	$page=isset($_GET['p'])?trim($_GET['p']):'';
	$base_title = !empty($setting['title'])? $setting['title'] : 'OverNotes';

?><?php
	$contribute=get_contribute($contribute_id);
		$title=$contribute['title'];
	$category_id=$contribute['category'];
	$category_data=unserialize(@file_get_contents(DATA_DIR.'/category/'.$category_id.'.dat'));
	$category_name=$category_data['name'];
	$category_text=@$category_data['text'];
	$category_url=$category_data['id'];
	$field_id=$contribute['field'];
	$id=$contribute['id'];
	$field=get_field($field_id);
	$date=$contribute['public_begin_datetime'];
	$url=$contribute['url'].'/';

	foreach($field as $field_index=>$field_data){
		${$field_data['code'].'_Name'}=$field_data['name'];
		${$field_data['code'].'_Value'}=make_value(
		$field_data['name']
				,@$contribute['data'][$field_id][$field_index]
			,$field_data['type']
			,$id
			,$field_id
			,$field_index
		);
		if($field_data['type']=='image'){
			${$field_data['code'].'_Src'}=ROOT_URI.'/_data/contribute/images/'.@$contribute['data'][$field_id][$field_index];
		}
	}

?>
<?php
$current_category_id   = $category_id;
$current_category_name = $category_name;
?>
<?php
	$category_index=get_category_index();
	foreach($category_index as $rowid=>$id){
		$category_data=unserialize(@file_get_contents(DATA_DIR.'/category/'.$id.'.dat'));
		$category_url=$category_data['id'];
		$category_name=$category_data['name'];
		$category_text=@$category_data['text'];
		$category_id=$id;
		${'category'.$id.'_url'}=$category_data['id'];
		${'category'.$id.'_name'}=$category_data['name'];
		${'category'.$id.'_text'}=@$category_data['text'];
		$selected=(@$_GET['c']==$id?' selected="selected"':'');

?>
<?php if( $current_category_id==$category_id ) $current_category_url = $category_url; ?>
<?php
	}
?>



<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">



<?php
	if($description_Value){
?>
<meta name="description" content="<?php echo $description_Value; ?>" />
<?php
	}
?>
<?php
	if($keywords_Value){
?>
<meta name="keywords" content="<?php echo $keywords_Value; ?>" />
<?php
	}
?>



<title><?php echo $title; ?>｜■■■■■■■■■■■■■■■■■■■■■■■</title>



<!-- Bootstrap -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
	<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<style>
.container{ width:950px !important; }
</style>
</head>

<body>
<div class="container">
<p class="text-center" style="padding:80px 0 40px;">
	<img src="../_sys/images/sys_logo.png" alt="キジカク" />
</p>



<!-- *********   H1   ********* -->
<h1 class="h6"><?php echo $title; ?>｜■■■■■■■■■■■■■■■■■■■■■■■</h1>
<!-- *********    /H1 ********* -->



<hr />
<div class="row">
	<div class="col col-xs-9">
		
		
		
		<!-- *********   BREADCRUMBS   ********* -->
		<ol class="breadcrumb">
			<li><a href="../../">ホーム</a></li>
			<li><a href="../">■■■■■■■■■■■■■■■■■■■■■■■</a></li>
			<li><a href="../<?php echo $current_category_url; ?>"><?php echo $current_category_name; ?></a></li>
			<li class="active"><?php echo $title; ?></li>
		</ol>
		<!-- *********    /BREADCRUMBS ********* -->
		
		
		
		<!-- *********   CONTENTS   ********* -->
		<div class="page-header">
			<h2><?php echo $title; ?></h2>
		</div>

		<div id="main" class="row">
			<div class="col-xs-6">
				<div class="panel panel-default">
					<div class="panel-body">
						<?php
	if($image1_Value){
?>
						<img src="<?php echo $image1_Src; ?>" alt="" class="img-responsive" style="margin: 0 auto" />
						<?php
	}
?>
					</div>
				</div>
			</div>
			
			<div class="col-xs-6">
				<?php echo $text1_Value; ?>
			</div>
		</div>

		<div class="text-center">
			<a href="../" class="btn btn-default">
				戻る
			</a>
		</div>
		<!-- *********    /CONTENTS ********* -->
		
		
	</div>
	<div class="col col-xs-3">
		<nav>
			<span class="label label-primary">カテゴリ</span>
			<ul class="nav nav-pills nav-stacked">
				
				
				
				<!-- *********   CATEGORIES   ********* -->
				<?php
	$category_index=get_category_index();
	foreach($category_index as $rowid=>$id){
		$category_data=unserialize(@file_get_contents(DATA_DIR.'/category/'.$id.'.dat'));
		$category_url=$category_data['id'];
		$category_name=$category_data['name'];
		$category_text=@$category_data['text'];
		$category_id=$id;
		${'category'.$id.'_url'}=$category_data['id'];
		${'category'.$id.'_name'}=$category_data['name'];
		${'category'.$id.'_text'}=@$category_data['text'];
		$selected=(@$_GET['c']==$id?' selected="selected"':'');

?>
				<li>
					<a href="../<?php echo $category_url; ?>"><?php echo $category_name; ?></a>
				</li>
				<?php
	}
?>
				<!-- *********    /CATEGORIES ********* -->
				
				
				
			</ul>
		</nav>
	</div>
</div>


</div>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
</body>
</html>