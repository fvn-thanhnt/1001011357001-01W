<?php

	$setting=unserialize(@file_get_contents(DATA_DIR.'/setting/overnotes.dat'));
	ini_set('mbstring.http_input', 'pass');
	parse_str($_SERVER['QUERY_STRING'],$_GET);
	$keyword=isset($_GET['k'])?trim($_GET['k']):'';
	$category=isset($_GET['c'])?trim($_GET['c']):'';
	$page=isset($_GET['p'])?trim($_GET['p']):'';
	$base_title = !empty($setting['title'])? $setting['title'] : 'OverNotes';

?><!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">



<meta name="description" content="<?php echo $current_category_name; ?>｜■■■■■■■■■■■■■■■■■■■■■■■" />
<meta name="keywords" content="<?php echo $current_category_name; ?>,■■■■■■■■■■■■■■■■■■■■■■■" />



<title><?php echo $current_category_name; ?>｜■■■■■■■■■■■■■■■■■■■■■■■</title>



<!-- Bootstrap -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
	<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<style>
.container{ width:950px !important; }
</style>
</head>

<body>
<div class="container">
<p class="text-center" style="padding:80px 0 40px;">
	<img src="../_sys/images/sys_logo.png" alt="キジカク" />
</p>



<!-- *********   H1   ********* -->
<h1 class="h6"><?php echo $current_category_name; ?>｜■■■■■■■■■■■■■■■■■■■■■■■</h1>
<!-- *********    /H1 ********* -->



<hr />
<div class="row">
	<div class="col col-xs-9">
		
		
		
		<!-- *********   BREADCRUMBS   ********* -->
		<ol class="breadcrumb">
			<li><a href="../../">ホーム</a></li>
			<li><a href="../">■■■■■■■■■■■■■■■■■■■■■■■</a></li>
			<li class="active"><?php echo $current_category_name; ?></li>
		</ol>
		<!-- *********    /BREADCRUMBS ********* -->
		
		
		
		<!-- *********   CATEGORY_TEXT   ********* -->
		<?php echo $current_category_text; ?>
		<!-- *********    /CATEGORY_TEXT ********* -->
		
		
		
		<!-- *********   POSTS   ********* -->
		<?php $limitNum = 20 ?>
		<?php
	$contribute_index=contribute_search(
		@$current_category_id
		,''
		,''
		,''
		,''
		,''
	);
	$max_record_count=count($contribute_index);

	$current_page=(@$_GET['p'])?(@$_GET['p']):1;
	$contribute_index=array_slice($contribute_index,($current_page-1)*$limitNum,$limitNum);
	$record_count=count($contribute_index)

?>
			
			<?php
	$local_index=0;
	foreach($contribute_index as $rowid=>$index){
		$contribute=unserialize(@file_get_contents(DATA_DIR.'/contribute/'.$index['id'].'.dat'));
		$title=$contribute['title'];
		$url=$contribute['url'].'/';
		$category_id=$index['category'];
		$category_data=unserialize(@file_get_contents(DATA_DIR.'/category/'.$category_id.'.dat'));
		$category_name=$category_data['name'];
		$category_text=@$category_data['text'];
		$field_id=$index['field'];
		$date=$index['public_begin_datetime'];
		$id=$index['id'];
		$field=get_field($field_id);

		foreach($field as $field_index=>$field_data){
			${$field_data['code'].'_Name'}=$field_data['name'];
			${$field_data['code'].'_Value'}=make_value(
		$field_data['name']
				,@$contribute['data'][$field_id][$field_index]
				,$field_data['type']
				,$id
				,$field_id
				,$field_index
			);
	
			if($field_data['type']=='image'){
				${$field_data['code'].'_Src'}=ROOT_URI.'/_data/contribute/images/'.@$contribute['data'][$field_id][$field_index];
			}
		}
		$local_index++;

?>
			<?php $url = "../{$url}" ?>
			<div class="panel panel-default">
				<div class="panel-body">
					<a href="<?php echo $url; ?>"><?php echo $title; ?></a>
				</div>
			</div>
			<?php
		foreach($field as $field_index=>$field_data){
			unset(${$field_data['code'].'_Name'});
			unset(${$field_data['code'].'_Value'});
			unset(${$field_data['code'].'_Src'});
		}
	}
?>
			
		
		<!-- *********    /POSTS ********* -->
		
		
		
		<!-- *********   PAGINATION   ********* -->
		<?php
	$page_count=(int)ceil($max_record_count/(float)$limitNum);
?>
			<?php
	if($max_record_count > $limitNum){
?>
				<ul class="pagination">
					<?php
	if($current_page <= 1){
?>
					<li class="disabled"><a href="#">&lt;&lt;</a></li>
					<?php
	}else{
?>
					<li><a href="./?p=<?php echo $current_page-1; ?>">&lt;&lt;</a></li>
					<?php
	}
?>
					
					<?php
	$page_old=@$page;
	for($page=1;$page<=$page_count;$page++){
?>
						<?php
	if($current_page == $page){
?>
						<li class="active"><a href="#"><?php echo $page; ?></a></li>
						<?php
	}else{
?>
						<li><a href="./?p=<?php echo $page; ?>"><?php echo $page; ?></a></li>
						<?php
	}
?>
					<?php
	}
$page=$page_old;
?>
					
					<?php
	if($current_page*$limitNum<$max_record_count){
?>
					<li><a href="./?p=<?php echo $current_page+1; ?>">&gt;&gt;</a></li>
					<?php
	}else{
?>
					<li class="disabled"><a href="#">&gt;&gt;</a></li>
					<?php
	}
?>
				</ul>
			<?php
	}
?>
		
		<!-- *********    /PAGINATION ********* -->
		
		
		
	</div>
	<div class="col col-xs-3">
		<nav>
			<span class="label label-primary">カテゴリ</span>
			<ul class="nav nav-pills nav-stacked">
				
				
				
				<!-- *********   CATEGORIES   ********* -->
				<?php
	$category_index=get_category_index();
	foreach($category_index as $rowid=>$id){
		$category_data=unserialize(@file_get_contents(DATA_DIR.'/category/'.$id.'.dat'));
		$category_url=$category_data['id'];
		$category_name=$category_data['name'];
		$category_text=@$category_data['text'];
		$category_id=$id;
		${'category'.$id.'_url'}=$category_data['id'];
		${'category'.$id.'_name'}=$category_data['name'];
		${'category'.$id.'_text'}=@$category_data['text'];
		$selected=(@$_GET['c']==$id?' selected="selected"':'');

?>
				<li>
					<a href="../<?php echo $category_url; ?>"><?php echo $category_name; ?></a>
				</li>
				<?php
	}
?>
				<!-- *********    /CATEGORIES ********* -->
				
				
				
			</ul>
		</nav>
	</div>
</div>


</div>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
</body>
</html>